#include "FFPlatform_private.h"
#include "common/io.h"
#include "common/library.h"
#include "common/strutil.h"
#include "common/windows/folders.h"
#include "common/windows/unicode.h"
#include "common/windows/registry.h"
#include "common/windows/nt.h"

#include <stdalign.h>
#include <windows.h>
#include <sddl.h>

#define SECURITY_WIN32 1 // For secext.h
#include <secext.h>

static void getExePath(FFPlatform* platform) {
    wchar_t exePathW[MAX_PATH];

    FF_AUTO_CLOSE_FD HANDLE hPath = CreateFileW(
        ffGetPeb()->ProcessParameters->ImagePathName.Buffer,
        GENERIC_READ,
        FILE_SHARE_READ,
        nullptr,
        OPEN_EXISTING,
        FILE_FLAG_BACKUP_SEMANTICS,
        nullptr);
    if (hPath != INVALID_HANDLE_VALUE) {
        DWORD len = GetFinalPathNameByHandleW(hPath, exePathW, MAX_PATH, FILE_NAME_NORMALIZED);
        if (len > 0 && len < MAX_PATH) {
            ffStrbufSetNWS(&platform->exePath, len, exePathW);
            if (ffStrbufStartsWithS(&platform->exePath, "\\\\?\\")) {
                ffStrbufSubstrAfter(&platform->exePath, 3);
            }
        }
    }

    if (platform->exePath.length == 0) {
        PCUNICODE_STRING imagePathName = &ffGetPeb()->ProcessParameters->ImagePathName;
        ffStrbufSetNWS(&platform->exePath, imagePathName->Length / sizeof(wchar_t), imagePathName->Buffer);
    }

    ffStrbufReplaceAllC(&platform->exePath, '\\', '/');
}

static void getCacheDir(FFPlatform* platform) {
    if (!ffGetKnownFolderPath(FF_KNOWN_FOLDER_LOCAL_APP_DATA, &platform->cacheDir)) {
        ffStrbufAppend(&platform->cacheDir, &platform->homeDir);
        ffStrbufAppendS(&platform->cacheDir, "AppData/Local/");
        return;
    }

    ffStrbufReplaceAllC(&platform->cacheDir, '\\', '/');
    ffStrbufEnsureEndsWithC(&platform->cacheDir, '/');
}

static void platformPathAddKnownFolder(FFlist* dirs, FFKnownFolder folder) {
    FF_STRBUF_AUTO_DESTROY buffer = ffStrbufCreate();
    if (!ffGetKnownFolderPath(folder, &buffer)) {
        return;
    }

    ffStrbufReplaceAllC(&buffer, '\\', '/');
    ffStrbufEnsureEndsWithC(&buffer, '/');
    if (!FF_LIST_CONTAINS(*dirs, &buffer, ffStrbufEqual)) {
        ffStrbufInitMove(FF_LIST_ADD(FFstrbuf, *dirs), &buffer);
    }
}

static void platformPathAddEnvSuffix(FFlist* dirs, const char* env, const char* suffix) {
    const char* value = getenv(env);
    if (!ffStrSet(value)) {
        return;
    }

    FF_STRBUF_AUTO_DESTROY buffer = ffStrbufCreateA(64);
    ffStrbufAppendS(&buffer, value);
    ffStrbufReplaceAllC(&buffer, '\\', '/');
    ffStrbufEnsureEndsWithC(&buffer, '/');
    if (suffix) {
        ffStrbufAppendS(&buffer, suffix);
        ffStrbufEnsureEndsWithC(&buffer, '/');
    }

    if (ffPathExists(buffer.chars, FF_PATHTYPE_DIRECTORY) && !FF_LIST_CONTAINS(*dirs, &buffer, ffStrbufEqual)) {
        ffStrbufInitMove(FF_LIST_ADD(FFstrbuf, *dirs), &buffer);
    }
}

static void getConfigDirs(FFPlatform* platform) {
    if (getenv("MSYSTEM")) {
        // We are in MSYS2 / Git Bash
        platformPathAddEnvSuffix(&platform->configDirs, "HOME", ".config/");
        platformPathAddEnvSuffix(&platform->configDirs, "HOME", nullptr);
        platformPathAddEnvSuffix(&platform->configDirs, "MINGW_PREFIX", "etc");
    }

    ffPlatformPathAddHome(&platform->configDirs, platform, ".config/");
    platformPathAddKnownFolder(&platform->configDirs, FF_KNOWN_FOLDER_PROGRAM_DATA);
    platformPathAddKnownFolder(&platform->configDirs, FF_KNOWN_FOLDER_ROAMING_APP_DATA);
    platformPathAddKnownFolder(&platform->configDirs, FF_KNOWN_FOLDER_LOCAL_APP_DATA);
    ffPlatformPathAddHome(&platform->configDirs, platform, "");
}

static void getDataDirs(FFPlatform* platform) {
    if (getenv("MSYSTEM") && getenv("HOME")) {
        // We are in MSYS2 / Git Bash
        platformPathAddEnvSuffix(&platform->dataDirs, "HOME", ".local/share/");
        platformPathAddEnvSuffix(&platform->dataDirs, "HOME", nullptr);
        platformPathAddEnvSuffix(&platform->dataDirs, "MINGW_PREFIX", "share");
    }
    ffPlatformPathAddHome(&platform->dataDirs, platform, ".local/share/");
    platformPathAddKnownFolder(&platform->dataDirs, FF_KNOWN_FOLDER_PROGRAM_DATA);
    platformPathAddKnownFolder(&platform->dataDirs, FF_KNOWN_FOLDER_ROAMING_APP_DATA);
    platformPathAddKnownFolder(&platform->dataDirs, FF_KNOWN_FOLDER_LOCAL_APP_DATA);
    ffPlatformPathAddHome(&platform->dataDirs, platform, "");
}

static void getUserName(FFPlatform* platform) {
    wchar_t buffer[256];
    DWORD size = ARRAY_SIZE(buffer);
    if (GetUserNameExW(NameDisplay, buffer, &size)) {
        ffStrbufSetWS(&platform->fullUserName, buffer);
    }

    NTSYSAPI NTSTATUS NTAPI LsaGetUserName(
        _Outptr_ PLSA_UNICODE_STRING * UserName,
        _Outptr_opt_ PLSA_UNICODE_STRING * DomainName);
    PLSA_UNICODE_STRING userName = nullptr;
    if (NT_SUCCESS(LsaGetUserName(&userName, nullptr))) {
        ffStrbufSetNWS(&platform->userName, userName->Length / sizeof(wchar_t), userName->Buffer);
        RtlFreeUnicodeString(userName); // Required. userName.Buffer is allocated separately
        LsaFreeMemory(userName);
    } else {
        ffStrbufSetS(&platform->userName, getenv("USERNAME"));
    }

    alignas(TOKEN_USER) char buf[SECURITY_MAX_SID_SIZE + sizeof(TOKEN_USER)];
    if (NT_SUCCESS(NtQueryInformationToken(NtCurrentProcessToken(), TokenUser, buf, sizeof(buf), &size))) {
        TOKEN_USER* tokenUser = (TOKEN_USER*) buf;
        UNICODE_STRING sidString = { .Buffer = buffer, .Length = 0, .MaximumLength = sizeof(buffer) };
        if (NT_SUCCESS(RtlConvertSidToUnicodeString(&sidString, tokenUser->User.Sid, FALSE))) {
            uint32_t sidLength = sidString.Length / sizeof(wchar_t);
            ffStrbufSetNWS(&platform->sid, sidLength, sidString.Buffer);

            // The SID is already in hand, so the profile directory costs one registry read rather
            // than a second NtQueryInformationToken(). ffGetProfilePath() needs a null-terminated
            // string, which RtlConvertSidToUnicodeString() does not produce.
            if (sidLength < ARRAY_SIZE(buffer)) {
                buffer[sidLength] = L'\0';
                ffGetProfilePath(buffer, &platform->homeDir);
            }
        }
    }

    if (platform->homeDir.length == 0) {
        ffStrbufSetS(&platform->homeDir, getenv("USERPROFILE")); // Last resort; ffGetProfilePath() covers the normal case
    }

    ffStrbufReplaceAllC(&platform->homeDir, '\\', '/');
    ffStrbufEnsureEndsWithC(&platform->homeDir, '/');
}

static void getHostName(FFPlatform* platform) {
    wchar_t buffer[256];
    DWORD len = ARRAY_SIZE(buffer);
    if (GetComputerNameExW(ComputerNameDnsHostname, buffer, &len) && len > 0) {
        ffStrbufSetNWS(&platform->hostName, len, buffer);
    } else {
        len = ARRAY_SIZE(buffer);
        if (GetComputerNameExW(ComputerNameNetBIOS, buffer, &len) && len > 0) {
            ffStrbufSetNWS(&platform->hostName, len, buffer);
        }
    }
}

static void getUserShell(FFPlatform* platform) {
    // Works in MSYS2
    const char* userShell = getenv("SHELL");
    if (userShell) {
        ffStrbufAppendS(&platform->userShell, userShell);
        ffStrbufReplaceAllC(&platform->userShell, '\\', '/');
    }
}

static const char* detectWine(void) {
    const char* __cdecl wine_get_version(void);
    void* hntdll = ffLibraryGetModule(L"ntdll.dll");
    if (!hntdll) {
        return nullptr;
    }
    FF_LIBRARY_LOAD_SYMBOL_LAZY(hntdll, wine_get_version);
    if (!ffwine_get_version) {
        return nullptr;
    }
    return ffwine_get_version();
}

static void getSystemReleaseAndVersion(FFPlatformSysinfo* info) {
    FF_AUTO_CLOSE_FD HANDLE hKey = nullptr;
    if (!ffRegOpenKeyForRead(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", &hKey, nullptr)) {
        return;
    }

    uint32_t ubr = 0;
    ffRegReadValues(hKey, 2, (FFRegValueArg[]) {
                                 FF_ARG(ubr, L"UBR"),
                                 FF_ARG(info->version, L"BuildLabEx"),
                             },
        nullptr);

    PPEB_FULL peb = ffGetPeb();

    ffStrbufSetF(&info->release,
        "%u.%u.%u.%u",
        (unsigned) peb->OSMajorVersion,
        (unsigned) peb->OSMinorVersion,
        (unsigned) peb->OSBuildNumber,
        (unsigned) ubr);

    const char* wineVersion = detectWine();
    if (wineVersion) {
        ffStrbufSetF(&info->name, "Wine_%s", wineVersion);
    } else {
        ffStrbufSetStatic(&info->name, "WIN32_NT");
    }
}

static void getSystemPageSize(FFPlatformSysinfo* info) {
    SYSTEM_BASIC_INFORMATION sbi;
    if (NT_SUCCESS(NtQuerySystemInformation(SystemBasicInformation, &sbi, sizeof(sbi), nullptr))) {
        info->pageSizeShift = (uint32_t) __builtin_ctzl(sbi.PhysicalPageSize);
    }
}

static void getSystemArchitecture(FFPlatformSysinfo* info) {
    switch (SharedUserData->NativeProcessorArchitecture) {
        case PROCESSOR_ARCHITECTURE_AMD64:
            ffStrbufSetStatic(&info->architecture, "x86_64");
            break;
        case PROCESSOR_ARCHITECTURE_IA64:
            ffStrbufSetStatic(&info->architecture, "ia64");
            break;
        case PROCESSOR_ARCHITECTURE_INTEL:
            ffStrbufSetStatic(&info->architecture, "i686");
            break;
        case PROCESSOR_ARCHITECTURE_ARM64:
            ffStrbufSetStatic(&info->architecture, "aarch64");
            break;
        case PROCESSOR_ARCHITECTURE_ARM:
            ffStrbufSetStatic(&info->architecture, "arm");
            break;
        case PROCESSOR_ARCHITECTURE_PPC:
            ffStrbufSetStatic(&info->architecture, "ppc");
            break;
        case PROCESSOR_ARCHITECTURE_MIPS:
            ffStrbufSetStatic(&info->architecture, "mips");
            break;
        case PROCESSOR_ARCHITECTURE_ALPHA:
            ffStrbufSetStatic(&info->architecture, "alpha");
            break;
        case PROCESSOR_ARCHITECTURE_ALPHA64:
            ffStrbufSetStatic(&info->architecture, "alpha64");
            break;
        case PROCESSOR_ARCHITECTURE_UNKNOWN:
        default:
            ffStrbufSetStatic(&info->architecture, "unknown");
            break;
    }
}

static void getCwd(FFPlatform* platform) {
    PCURDIR cwd = &ffGetPeb()->ProcessParameters->CurrentDirectory;
    ffStrbufSetNWS(&platform->cwd, cwd->DosPath.Length / sizeof(WCHAR), cwd->DosPath.Buffer);
    ffStrbufReplaceAllC(&platform->cwd, '\\', '/');
    ffStrbufEnsureEndsWithC(&platform->cwd, '/');
}

void ffPlatformInitImpl(FFPlatform* platform) {
    platform->pid = (uint32_t) (uintptr_t) ffGetTeb()->ClientId.UniqueProcess;
    getExePath(platform);
    getCwd(platform);

    getUserName(platform);

    getCacheDir(platform);
    getConfigDirs(platform);
    getDataDirs(platform);
    getHostName(platform);
    getUserShell(platform);

    getSystemReleaseAndVersion(&platform->sysinfo);
    getSystemArchitecture(&platform->sysinfo);
    getSystemPageSize(&platform->sysinfo);
}

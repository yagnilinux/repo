#include "common/binary.h"
#include "common/debug.h"
#include "common/io.h"
#include "common/strutil.h"
#include "common/windows/nt.h"

#include <windows.h>
#include <stdlib.h>
#include <string.h>

/**
 * Extracts string literals from a PE (Windows) executable
 *
 * This function maps the PE file into memory, locates the .rdata section
 * (which typically contains string literals), and scans it for valid strings.
 * Each string found is passed to the callback function for processing.
 */
const char* ffBinaryExtractStrings(const char* peFile, bool (*cb)(const char* str, uint32_t len, void* userdata), void* userdata, uint32_t minLength) {
    FF_AUTO_CLOSE_FD HANDLE hFile = CreateFileA(peFile, GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (hFile == INVALID_HANDLE_VALUE) {
        FF_DEBUG("CreateFileA() failed: %s", ffDebugWin32Error(GetLastError()));
        return "CreateFileA() failed";
    }

    FF_AUTO_CLOSE_FD HANDLE hSection = nullptr;
    NTSTATUS status = NtCreateSection(&hSection, SECTION_MAP_READ, nullptr, nullptr, PAGE_READONLY, SEC_COMMIT, hFile);
    if (!NT_SUCCESS(status)) {
        FF_DEBUG("NtCreateSection() failed: %s", ffDebugNtStatus(status));
        return "NtCreateSection() failed";
    }

    PVOID base = nullptr;
    SIZE_T viewSize = 0;
    status = NtMapViewOfSection(hSection, NtCurrentProcess(), &base, 0, 0, nullptr, &viewSize, ViewUnmap, 0, PAGE_READONLY);
    if (!NT_SUCCESS(status)) {
        FF_DEBUG("NtMapViewOfSection() failed: %s", ffDebugNtStatus(status));
        return "NtMapViewOfSection() failed";
    }

    PIMAGE_NT_HEADERS ntHeaders = RtlImageNtHeader(base);
    if (!ntHeaders) {
        FF_DEBUG("RtlImageNtHeader() failed");
        NtUnmapViewOfSection(NtCurrentProcess(), base);
        return "RtlImageNtHeader() failed";
    }

    PIMAGE_SECTION_HEADER section = IMAGE_FIRST_SECTION(ntHeaders);
    for (WORD i = 0; i < ntHeaders->FileHeader.NumberOfSections; ++i, ++section) {
        // Look for initialized data sections with the name ".rdata" which typically contains string literals
        if ((section->Characteristics & IMAGE_SCN_CNT_INITIALIZED_DATA) && ffStrEquals((const char*) section->Name, ".rdata")) {
            uint8_t* data = (uint8_t*) base + section->PointerToRawData;

            // Scan the section for string literals
            for (size_t off = 0; off < section->SizeOfRawData; ++off) {
                const char* p = (const char*) data + off;
                if (*p == '\0') {
                    continue;
                }
                uint32_t len = (uint32_t) strnlen(p, section->SizeOfRawData - off);
                if (len < minLength) {
                    off += len;
                    continue;
                }
                // Only process printable ASCII characters
                if (*p >= ' ' && *p <= '~') // Ignore control characters
                {
                    if (!cb(p, len, userdata)) {
                        break;
                    }
                }
                off += len;
            }
        }
    }

    NtUnmapViewOfSection(NtCurrentProcess(), base);
    return nullptr;
}
